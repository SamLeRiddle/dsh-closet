export const name = 'dsh-closet-multi-panels'
export function apply() {}
