window.__ModuleLoader__.load({
  id: 'dsh-closet-multi-panels',
  factory(require) {
    const React = require('react')
    return {
      isPlugin: true,
      inject: ['slots'],
      apply(ctx) {
        for (const [id, label, order] of [
          ['closet-test-note', '测试便签', 2],
          ['closet-test-stats', '测试统计', 3],
          ['closet-test-search', '测试搜索', 4],
          ['closet-test-files', '测试文件', 6],
          ['closet-test-tasks', '测试任务', 7],
          ['closet-test-logs', '测试日志', 8],
        ]) {
          ctx.slots.inject('sidebar.panellist', () => ctx.slots.register({
            name: 'sidebar.panellist', id, order, label: () => label,
          }, () => React.createElement('span', { 'data-test-panel-icon': id }, '◇')))
          ctx.slots.inject('main', () => ctx.slots.register({
            name: 'main', key: id,
          }, () => React.createElement('div', {
            'data-test-panel': id, style: { padding: 30 },
          }, label + '面板已打开')))
        }
      },
    }
  },
})
