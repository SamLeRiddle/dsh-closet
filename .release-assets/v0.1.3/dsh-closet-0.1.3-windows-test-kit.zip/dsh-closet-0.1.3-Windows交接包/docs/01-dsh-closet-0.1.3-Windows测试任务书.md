# dsh-closet 0.1.3 Windows 测试任务书

日期：2026-11-05  
对象：在原生 Windows 上执行验收的 agent  
目标：确认 0.1.3 两项修复有效，多匣功能没有回归，并记录实际 Desktop 的稳定性和已知限制。

## 一、先确认版本和范围

本次测试对象是交接包内 `plugin/dsh-closet` 的 **0.1.3**。编写本任务书时，GitHub main 仍为 0.1.2；不要直接克隆 main 后当作 0.1.3 验收。先核对插件 package.json 和 SHA256SUMS.json。

0.1.3 修复了：

1. 配置因权限、占用等原因暂时读不出时，返回读取失败，不再把有效配置移走并重建为空匣。
2. 改名按 Esc 时取消编辑，不再被紧随的失焦事件保存，也不再连带关闭设置页。

还调整了损坏 JSON 的恢复：先成功备份再重建；已有 `.broken` 备份不得覆盖，后续依次使用 `.broken.1` 等名称。

已有证据：20 项 Node 回归通过；Linux DSH Web 0.2.1-rc.5 的真实浏览器已验证读取失败、恢复重试、Esc、后续正常改名及动态启停。本次 **尚无 0.1.3 Windows Desktop 验收结论**。包内历史证据只供参考，不能填作本次 Windows PASS。

本次没有修复语言适配、同名入口区分，以及对宿主侧栏 DOM 结构的依赖。主要功能用中文界面、名称唯一的入口验收；兼容性现象单独记录。

## 二、交付文件

- `plugin/dsh-closet/`：完整 0.1.3 插件，含源码、20 项测试及 README 示意图。
- `fixtures/dsh-closet-multi-panels/`：六个测试入口及对应面板，无需调用模型 API。
- `docs/01-dsh-closet-0.1.3-Windows测试任务书.md`：本任务书。
- `docs/02-Windows测试结果模板.md`：填写后回传，保留逐项证据。
- `docs/03-0.1.3修复记录.md`：修复范围与已有验证。
- `tools/Hold-TestConfig.ps1`：在独立测试配置上阻止读取或原子替换；不会修改文件内容或 ACL。
- `tools/desktop-slow-save.js`：在真实 renderer 中延迟首条保存响应，观察保存队列。
- `tools/Verify-Package.ps1`、`SHA256SUMS.json`：校验包内文件。
- `evidence/linux/`：已有 Linux 结果摘要，不能替代 Windows 测试。

本次新增的 PowerShell 锁辅助脚本尚未在 Windows 运行。它只是故障注入工具；是否注入成功必须以实际 GET/POST 或 rename 失败为证据，不能只看脚本已启动。

## 三、环境和执行边界

优先用原生 Windows 10/11 x64、官方 DSH Desktop，记录 OS、Desktop、Electron、内置 dsh 和 Node 的精确版本。此前检查参考的 Desktop 为 0.2.2-rc.1；若实际使用新版本，以实际版本为准，不要求降级或关闭更新。

必须做到：

1. 使用独立测试 `DSH_HOME` 和 Electron user-data，不动日常使用的配置。
2. 只管理本次创建并记录 PID 的进程；不得按端口、名称或进程范围批量结束 DSH/Node。不得删除运行中实例的锁文件。
3. 若 Desktop 单实例机制阻止隔离实例启动，或者测试 agent 自身依赖当前 Desktop 而无法完整退出，记录 BLOCKED，改用独立 Windows 机器或虚拟机。普通浏览器或 HTTP Host 通过不能替代 Desktop 验收，也不能写成“等价通过”。
4. 不修改 DSH 宿主代码、客户端协议或登录状态来制造通过；遇到登录或权限阻塞，如实记录。
5. 锁文件和损坏配置试验只对本次随机测试目录操作。不要修改真实用户目录 ACL、系统环境变量或全局执行策略。
6. 截图、日志、网络记录去除 token、Cookie、密钥和个人信息。只记录请求方法、无凭据路径、状态码及必要响应字段。

## 四、准备和安装

解压后进入交接包根目录，先校验：

```powershell
powershell.exe -NoProfile -File .\tools\Verify-Package.ps1
```

若脚本执行策略阻止运行，用 Get-FileHash 人工核对并记录，不修改全局执行策略。记录包校验结果、插件版本和源码摘要。

以下使用同一个 PowerShell 会话。将安装路径替换为机器上的真实路径，不要照抄占位路径：

```powershell
$ErrorActionPreference = 'Stop'
$bundleRoot = (Get-Location).Path
$installDir = 'C:\请替换为实际安装目录\DeepSeek Harness'
$desktopExe = Join-Path $installDir 'DeepSeek Harness.exe'
$desktopDsh = Join-Path $installDir 'resources\runtime\cli\bin\dsh.cmd'
if (-not (Test-Path -LiteralPath $desktopExe -PathType Leaf)) { throw 'Desktop executable not found' }
if (-not (Test-Path -LiteralPath $desktopDsh -PathType Leaf)) { throw 'Bundled dsh not found' }
$pluginDir = (Resolve-Path -LiteralPath (Join-Path $bundleRoot 'plugin\dsh-closet')).Path
$testPanels = (Resolve-Path -LiteralPath (Join-Path $bundleRoot 'fixtures\dsh-closet-multi-panels')).Path
$testRoot = Join-Path $env:TEMP ('dsh-closet-013-' + [guid]::NewGuid().ToString('N'))
$testHome = Join-Path $testRoot 'home'
$testUserData = Join-Path $testRoot 'electron-user-data'
New-Item -ItemType Directory -Path $testHome, $testUserData | Out-Null
[IO.File]::WriteAllText((Join-Path $testHome '.dsh-closet-013-test-home'), 'isolated test home')
$previousDshHome = $env:DSH_HOME
$env:DSH_HOME = $testHome
$desktopArgs = '--user-data-dir="{0}"' -f $testUserData
& $desktopDsh --version
$desktopProcess = Start-Process -FilePath $desktopExe -ArgumentList $desktopArgs -PassThru
```

记录实际测试目录和本次 PID。确认 Desktop 确实使用上述目录，并完成 `profiles/desktop` 初始化。然后从应用或托盘菜单完整退出该测试实例，确认它的主进程和 Host 已退出，再安装：

```powershell
& $desktopDsh plugin --profile desktop add $pluginDir $testPanels
if ($LASTEXITCODE -ne 0) { throw 'Plugin installation failed' }
& $desktopDsh plugin --profile desktop list --depth 0
if ($LASTEXITCODE -ne 0) { throw 'Plugin inventory failed' }
$desktopProcess = Start-Process -FilePath $desktopExe -ArgumentList $desktopArgs -PassThru
$configFile = Join-Path $testHome 'config\dsh-closet.json'
```

使用实际版本提供的插件管理界面安装本地目录也可以，记录实际方法。不要手写 profile manifest 来伪装安装成功；不要用 npm 的 Web CLI 替代 Desktop 自带 CLI；不要把客户端 `platform: web` 改成 desktop。

进入真实 Desktop 主应用 renderer，记录脱敏的 location.protocol、页面主路径、navigator.userAgent 和 `window.__DSH_CLOSET_CONFIG__`。此前正式 Desktop 使用 `dsh-app://app/`；若新版实际协议不同，记录版本和实际加载链路，不伪造预期协议。实际配置 GET/POST 必须经过当前 Desktop Host。

## 五、必测用例

每项标 PASS、FAIL、BLOCKED 或未执行。细分步骤未全测时不能整项 PASS；可分别记录 Host 和 Desktop UI 结果。

### T01：版本与 Desktop 真实性

确认 0.1.3 和六入口夹具均激活；设置页“匣”可进入，新装夹具入口默认在匣外。保留版本、原生窗口、renderer 协议和配置请求证据。

通过标准：版本正确、隔离生效、确为 Desktop 主应用；无本插件引起的启动异常或未捕获页面错误。

### T02：三个匣、六入口和基本回归

建立以下基线，等待“已保存”，备份完整配置到本次 evidence 目录并计算 SHA-256：

| 匣 | 入口 |
| --- | --- |
| 常用 | 测试便签、测试统计 |
| 开发 | 测试搜索、测试文件 |
| 工具 | 测试任务、测试日志 |

逐项测试独立展开/收起；六个代理入口各打开正确原面板；活动高亮和收起后圆点；跨匣移动；排序；同名匣仍按 ID 隔离；删除匣只释放本匣成员；再新建无 ID 冲突。移到匣外的入口应恢复原行并可点击，收进匣的原行不重复占位。

注意“同名匣”与“同名插件入口”是不同情况：前者应正常，后者属于 K02 的已知限制。官方自动化任务夹在两个匣之间属于目前布局，不据此判失败。

后续故障试验前恢复上述三匣六入口基线，并保存配置备份、哈希和 config 目录清单。

### T03（P0）：真实读取失败不能重建空匣

在第二个 PowerShell 会话设置本次实际测试 home；必须与主会话输出的路径一致：

```powershell
$testHome = '替换为本次实际测试home完整路径'
$env:DSH_HOME = $testHome
powershell.exe -NoProfile -File '替换为交接包路径\tools\Hold-TestConfig.ps1' -TestHome $testHome -Mode DenyRead -HoldSeconds 180
```

等待 `LOCK_ACQUIRED`。此模式使用 FileShare.None，目的是让实际 Node 读取失败。原先只允许共享读取的写锁不能代替本项。

1. 保持句柄，刷新实际 Desktop 主页面，观察真实配置 GET。
2. 预期 Host 返回 503，响应 `ok: false`、`error: configuration read failed` 及实际错误码，不含默认 config。Windows 错误码不要求固定为 EACCES 或 EBUSY。
3. UI 显示读取失败并可重试，不应把原三匣显示成已成功读取的默认空匣，也不应自行 POST 默认配置。
4. 对比 config 目录清单，不应新增 `.broken`。独占锁期间无法读取配置计算哈希是正常的；不要为取证提前解锁。
5. 释放句柄（可等脚本超时，或用另一会话在同一测试 home 创建 `release-closet-lock.signal`）。等待 `LOCK_RELEASED`，检查脚本输出的前后 SHA-256 相同。
6. 点击页面“重试”，应恢复原有三匣六入口、归属、名称、顺序和展开状态；重新核对磁盘原始字节及目录清单。

通过标准：真实读取失败已发生、503 和 UI 错误均有证据、原配置未改写或移动、释放后正确恢复。没有触发真实失败只能标故障注入未生效，不能 PASS。

### T04：文件不存在时才创建默认配置

在独立测试目录保存基线备份，退出本次测试实例，将配置文件改名保留，再启动。预期创建合法默认配置并出现一个空匣，无读取失败。确认后退出，用基线备份恢复；不得误操作日常配置。

本项只验证缺失时初始化，不要求原本已经不存在的配置自行恢复出三匣。

### T05：损坏 JSON 的备份不覆盖历史文件

完整退出本次测试实例。保存基线到 evidence 目录；若已有 `.broken` 文件，保留并记录各自哈希。向测试 config 写入确定无效 JSON，例如 `{invalid json`；若 `.broken` 尚不存在，预先创建一个内容为历史哨兵字符串的 `.broken`，存在则直接沿用且不改写。使用不带 BOM 的 UTF-8，例如：

```powershell
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[IO.File]::WriteAllText($configFile, '{invalid json', $utf8NoBom)
```

启动并触发 GET。预期：原 `.broken` 字节不变；无效 JSON 被完整保留到下一个可用的 `.broken.N`；随后生成合法默认配置。恢复基线，再重复一次以验证不会覆盖上一轮备份。每轮记录目录清单和各文件哈希。

通过标准：仅在 JSON 确实解析失败时才进入备份恢复；每次均先成功备份再重建；历史备份保持不变。最后退出并恢复基线。

### T06（P0）：备份失败时原损坏文件也必须保留

在测试实例仍运行、没有待保存修改时，保存基线，将测试文件写为无效 JSON。用 `Hold-TestConfig.ps1 -Mode DenyReplace` 持有共享读取、禁止替换的句柄。脚本启动后不得手动编辑设置，随后刷新 Desktop 触发读取。

预期：读取能进行，但无效 JSON 的改名备份确实失败；GET 返回 503、UI 显示错误，原无效文件字节不变，没有默认配置覆盖它，也没有伪造成功备份。释放后先保存原文件哈希证据，再点击重试；应完成备份并重建默认配置。

若实际系统没有阻止 rename，注入未生效，不能标 PASS；可记录阻塞或使用可说明的 Windows 原生等效方法，不改宿主和插件实现。最后完整退出并恢复三匣基线。

### T07（P0）：Esc 取消改名，之后正常提交仍有效

等保存队列空闲，记录原配置哈希并清空 DevTools 网络记录。把“常用”改成“此名不应保存”，保持输入焦点，按 Esc。

必须同时满足：名称立即恢复；设置窗口保持打开；Esc 和随后失焦都不产生配置 POST；切到别处再刷新，原名及磁盘字节不变。

再分别验证 Enter 提交和普通点击外部失焦提交，两者应正常保存。最后做一次中文输入法组合输入，检查 Esc 不会误保存；如与输入法行为冲突，记录实际事件和输入法版本，不假定通过。

### T08：写入失败、编辑保留和重试

恢复有效基线，用 `DenyReplace` 持锁。改名或移动入口，确认实际 POST 失败（当前实现通常返回 400），UI 显示保存失败和“重试保存”，编辑仍保留，磁盘配置不变。释放后点击重试，最终 UI、GET 和磁盘完整配置一致；刷新后仍保留。

本项不能替代 T03：它验证写入失败；T03 必须验证读取失败。

### T09：连续操作和慢响应保存队列

在真实 Desktop renderer 粘贴 `tools/desktop-slow-save.js`；它发起真实请求，只暂存首条配置 POST 的响应交给 UI 的时机，不伪造返回内容。

首次更改后确认 `heldResponse: true`，保持响应未放行，再做改名、展开收起和跨匣移动等连续操作。执行 `window.__DSH_CLOSET_SAVE_TEST__.report()` 记录：放行前只能发起一条目标 POST，`maxActive` 应为 1，UI 保留最新操作。

执行 `.release()`，等待“已保存”，比对完整快照；旧响应不得回滚 UI，刷新后应保留最终设置。记录 report 后执行 `.restore()`。工具 120 秒自动放行；若已 `autoReleased`，重做或说明时序证据不足。

### T10：其他插件启停与匣自身停用

停用六入口夹具后，代理入口与数量同步消失，不留点不动的行；配置中的归属记录保留。重新启用夹具，六入口恢复原匣。按宿主实际要求区分热启停和需重启两种情况，不通过手工删除 DOM 模拟卸载。

停用“匣”本身，确认六个原始入口恢复、隐藏样式与事件处理注销；再启用后恢复已保存配置，无重复行或重复处理。卸载检查可在后续专门的测试副本执行，保留配置文件不代表卸载失败。

### T11：刷新、完整重启和自定义前缀

分别验证页面刷新、测试 Desktop 主进程及 Host 完整退出后重启。关闭窗口但仍驻留后台不能算完整重启。三匣的 ID、名称、顺序、归属和展开状态都应恢复。

备份当前测试 profile patch，在本插件配置中设置 `routePrefix: /custom`，按宿主要求重启。验证页面注入值、真实 Desktop 协议下 GET/POST 路径、落盘、刷新与完整重启；不再请求旧 `/closet/api/config`。另检查 `/tools/closet/` 和 `/`（对应 `/api/config`），逐个记录。不要覆盖 profile 中其他配置行，完成后恢复原 patch。

### T12：交互和正常宿主功能

检查展开侧栏、图标侧栏、浅色/深色主题、鼠标及 Enter/Space 操作。插件市场、自动化任务、更多、工作区和原有面板仍可进入。若当前版本有固定/取消固定功能，检查其与匣的相互影响；功能不存在可标 N/A 并写版本依据。

### T13：卡顿、错误及退出后恢复

这是稳定性抽查，不能得出“所有电脑永不崩溃”的结论。

1. 记录测试实例进程树及空闲 CPU、内存基线。
2. 三匣各做至少 30 次展开/收起，交替打开六个面板；连续修改至少 20 次，等待保存后核对最终配置。
3. 正常切换设置和面板约 5 分钟，再空闲观察 5 分钟；记录相同进程范围的 CPU、内存和时间点。瞬时波动不直接判失败；持续高占用、持续增长或操作迟滞需复现并给数值。
4. 检查 renderer 未捕获异常、Host 异常、崩溃/重启、重复行或请求风暴。出现时保留首次错误、操作序列、相关 PID 和时间；先记录，不直接把所有宿主错误归因于插件。
5. 停用匣后再核对原入口恢复和资源占用。发现 DSH 异常时停止注入故障，先释放本次文件句柄、恢复 fetch，再按本次 PID 处理测试实例。

### T14：Windows Node 回归

在交接包的插件目录，用实际 Windows Node 运行 `npm test` 或 `node --test tests/*.test.mjs`，保留版本和完整摘要，预期 20 项通过。若因路径通配符或运行环境不能启动，记录原因；任何更换参数都要说明，不能删除或跳过失败用例。

Node 通过只代表自动回归，不替代 T01—T13 的 Desktop 证据。

## 六、已知兼容性限制的记录

### K01：语言切换

使用单独测试副本或先保存快照。切换到英文，记录官方入口是否被列成可收纳项、已有归属是否因标签变化而匹配不上、切回中文是否恢复；记录设置页文案仍为中文的情况。不要把官方入口收进日常使用的匣。若为了复现而收纳，只在测试副本进行并恢复。

当前实现只按中文标签排除官方行。英文及其他语言 **未适配**，本项可记 KNOWN_LIMITATION，不能写“英文支持通过”。如果目标是宣称多语言可用，该限制必须先修复并重新验收。

### K02：同名或改名的插件入口

区分两个同名的匣与两个同名的插件入口。当前入口依赖显示标签识别，相同标签可能合并且点击首个匹配行；入口改名或随语言变化后，原归属可能无法匹配。

如能在测试夹具副本新增两个同名入口或更改入口文案，记录现象和恢复过程；不要直接改本交接包夹具基线。没有夹具条件则标未执行，并保留“代码已知限制”说明，不能据此声称已解决。

## 七、结果交付和放行标准

填写 `02-Windows测试结果模板.md`，交付环境版本、各用例状态、可复现缺陷、脱敏截图/日志、配置前后哈希、进程与资源观察记录，以及临时改动的恢复情况。

结论分为：

- **通过（限定范围）**：T01—T14 的适用必测步骤完成，P0 全通过，无配置丢失、崩溃、持续卡顿或错误入口；仅对实际 Windows/DSH 版本、中文且入口名称唯一的条件负责。K01/K02 仍应对外说明。
- **未通过**：出现缺陷，列触发步骤、预期/实际、影响、证据；特别标出配置被改写、Esc 误保存、宿主崩溃或卸载后入口仍隐藏。
- **阻塞或部分完成**：Desktop 未实际进入、单实例冲突、故障注入未生效、关键步骤未执行或缺证据。分别列已完成 Host/Node 结果与待补 Desktop 项，不合并成通过。

测试后释放句柄、恢复 fetch 与原 profile patch；恢复临时进程环境变量，完整退出本次测试实例。保留证据和基线备份；不要在回传前批量删除测试目录。

如果发现缺陷需要修复，先保存未修改基线、失败证据和源码哈希；在新副本修改，单独交付差异、修复前后验证和新版本标识。本任务不授权修改 GitHub main 或替换用户日常 DSH。
