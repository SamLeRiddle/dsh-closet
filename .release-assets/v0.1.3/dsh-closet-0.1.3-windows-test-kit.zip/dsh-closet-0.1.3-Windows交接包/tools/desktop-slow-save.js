/*
 * 在实际 DSH Electron 窗口的 DevTools Console 中完整粘贴本文件。
 * 临时延迟第一个配置 POST 的响应交给界面的时机，便于连续操作测试。
 * 所有请求都发送给真实 Host，响应对象原样返回；本工具不伪造配置。
 * 查看：window.__DSH_CLOSET_SAVE_TEST__.report()
 * 放行：window.__DSH_CLOSET_SAVE_TEST__.release()
 * 恢复：window.__DSH_CLOSET_SAVE_TEST__.restore()
 * 第一个目标 POST 开始后 120 秒自动放行，避免长期卡住保存。
 */
;(function installClosetSlowSaveTest() {
  'use strict'
  var existing = window.__DSH_CLOSET_SAVE_TEST__
  if (existing && (typeof existing.report !== 'function' || !existing.report().restored)) {
    console.warn('匣的慢保存测试已安装；请先执行 window.__DSH_CLOSET_SAVE_TEST__.restore()，再重新粘贴。')
    return existing
  }

  var boot = window.__DSH_CLOSET_CONFIG__ || {}
  var prefix = typeof boot.routePrefix === 'string' ? boot.routePrefix : '/closet'
  var relativePrefix = prefix.replace(/^\/+|\/+$/g, '')
  var target = new URL((relativePrefix ? relativePrefix + '/' : '') + 'api/config', document.baseURI)
  var originalFetch = window.fetch
  var startedAt = Date.now()
  var startedCount = 0
  var active = 0
  var maxActive = 0
  var gateReleased = false
  var releaseReason = null
  var autoReleased = false
  var heldResponse = false
  var restored = false
  var releaseTimer = null
  var logs = []
  var openGate
  var gate = new Promise(function (resolve) { openGate = resolve })

  function log(event, requestNumber) {
    var entry = { elapsedMs: Date.now() - startedAt, event: event, active: active }
    if (requestNumber !== undefined) entry.requestNumber = requestNumber
    logs.push(entry)
  }

  function report() {
    return {
      targetUrl: target.origin + target.pathname,
      startedCount: startedCount,
      active: active,
      maxActive: maxActive,
      heldResponse: heldResponse,
      gateReleased: gateReleased,
      releaseReason: releaseReason,
      autoReleased: autoReleased,
      restored: restored,
      logs: logs.map(function (entry) { return Object.assign({}, entry) })
    }
  }

  function clearReleaseTimer() {
    if (releaseTimer !== null) {
      clearTimeout(releaseTimer)
      releaseTimer = null
    }
  }

  function releaseGate(reason) {
    clearReleaseTimer()
    if (gateReleased) return
    gateReleased = true
    releaseReason = reason
    if (reason === 'automatic') autoReleased = true
    log(reason === 'automatic' ? 'auto-release' : 'release-' + reason)
    openGate()
  }

  function isConfigurationPost(input, init) {
    try {
      var isRequest = typeof Request === 'function' && input instanceof Request
      var override = init == null ? undefined : init.method
      var method = override !== undefined ? override : isRequest ? input.method : 'GET'
      if (String(method).toUpperCase() !== 'POST') return false
      var url = new URL(isRequest ? input.url : input, document.baseURI)
      return url.origin === target.origin && url.pathname === target.pathname
    } catch (error) {
      // Let native fetch validate inputs; this observer must not replace its error.
      return false
    }
  }

  function finish(requestNumber, event) {
    active--
    log(event, requestNumber)
  }

  function wrappedFetch(input, init) {
    if (!isConfigurationPost(input, init)) return originalFetch.apply(this, arguments)
    var requestNumber = ++startedCount
    active++
    maxActive = Math.max(maxActive, active)
    log('request-started', requestNumber)
    if (requestNumber === 1 && !gateReleased) {
      releaseTimer = setTimeout(function () { releaseGate('automatic') }, 120000)
    }
    var pending
    try {
      // Keep the original receiver and arguments, including Request streams and init overrides.
      pending = originalFetch.apply(this, arguments)
    } catch (error) {
      finish(requestNumber, 'request-threw')
      if (requestNumber === 1) releaseGate('first-request-failed')
      throw error
    }
    return Promise.resolve(pending).then(function (response) {
      log('response-ready', requestNumber)
      if (requestNumber === 1 && !gateReleased) {
        heldResponse = true
        log('response-held', requestNumber)
        return gate.then(function () {
          heldResponse = false
          finish(requestNumber, 'response-delivered')
          return response
        })
      }
      finish(requestNumber, 'response-delivered')
      return response
    }, function (error) {
      finish(requestNumber, 'request-rejected')
      if (requestNumber === 1) releaseGate('first-request-failed')
      throw error
    })
  }

  var controller = {
    report: report,
    release: function () {
      releaseGate('manual')
      return report()
    },
    restore: function () {
      if (!restored) {
        releaseGate('restore')
        window.fetch = originalFetch
        restored = true
        log('restored')
      }
      clearReleaseTimer()
      return report()
    }
  }
  window.fetch = wrappedFetch
  window.__DSH_CLOSET_SAVE_TEST__ = controller
  log('installed')
  console.info('匣的慢保存测试已安装，目标为 ' + target.origin + target.pathname + '。查看 report()，放行 release()，结束后务必 restore()：window.__DSH_CLOSET_SAVE_TEST__。')
  return controller
})()
