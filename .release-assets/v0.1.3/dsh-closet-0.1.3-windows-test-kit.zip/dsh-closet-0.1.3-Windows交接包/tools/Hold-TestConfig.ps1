# Windows test helper: hold only the marked, isolated 0.1.3 test configuration.
# DenyRead blocks reads; DenyReplace permits reads but blocks replacement.
# This script does not edit file bytes, attributes, ACLs, or system settings.
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TestHome,
    [Parameter(Mandatory = $true)][ValidateSet('DenyRead', 'DenyReplace')][string]$Mode,
    [ValidateRange(10, 300)][int]$HoldSeconds = 180
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'This helper requires Windows.' }
$resolvedHome = (Resolve-Path -LiteralPath $TestHome).Path
if ([string]::IsNullOrWhiteSpace($env:DSH_HOME)) { throw 'DSH_HOME is not set in this shell.' }
$environmentHome = (Resolve-Path -LiteralPath $env:DSH_HOME).Path
if ($resolvedHome -ne $environmentHome) { throw 'TestHome must match this process DSH_HOME.' }
if (-not (Test-Path -LiteralPath (Join-Path $resolvedHome '.dsh-closet-013-test-home') -PathType Leaf)) {
    throw 'Missing isolated-test marker; do not use a live user home.'
}
$rootInfo = Get-Item -LiteralPath $resolvedHome
if ($rootInfo.Name -ne 'home' -or $rootInfo.Parent.Name -notmatch '^dsh-closet-013-[a-fA-F0-9]{32}$') {
    throw 'TestHome must be the randomized home created by the task instructions.'
}
$directory = Join-Path $resolvedHome 'config'
$file = Join-Path $directory 'dsh-closet.json'
$current = Get-Item -LiteralPath $file
if ($current.PSIsContainer) { throw 'Configuration must be a file.' }
while ($null -ne $current) {
    if ($current.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse-point targets are not supported.' }
    if ($current -is [IO.FileInfo]) { $current = $current.Directory }
    else { $current = $current.Parent }
}
$releaseFile = Join-Path $resolvedHome 'release-closet-lock.signal'
if (Test-Path -LiteralPath $releaseFile) { throw 'A stale release signal exists; inspect and remove it before retrying.' }
$beforeHash = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
$share = [IO.FileShare]::None
if ($Mode -eq 'DenyReplace') { $share = [IO.FileShare]::Read }
$handle = $null
try {
    $handle = [IO.File]::Open($file, [IO.FileMode]::Open, [IO.FileAccess]::Read, $share)
    Write-Output 'LOCK_ACQUIRED'
    Write-Output ('Mode=' + $Mode)
    Write-Output ('ConfigPath=' + $file)
    Write-Output ('OriginalSHA256=' + $beforeHash)
    Write-Output ('ReleaseSignal=' + $releaseFile)
    Write-Output ('AutomaticReleaseSeconds=' + $HoldSeconds)
    $clock = [Diagnostics.Stopwatch]::StartNew()
    while ($clock.Elapsed.TotalSeconds -lt $HoldSeconds -and -not (Test-Path -LiteralPath $releaseFile)) {
        Start-Sleep -Milliseconds 250
    }
}
finally {
    if ($null -ne $handle) {
        $handle.Dispose()
        Write-Output 'LOCK_RELEASED'
        if (Test-Path -LiteralPath $file -PathType Leaf) {
            $afterHash = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
            Write-Output ('SHA256AfterRelease=' + $afterHash)
            Write-Output ('FileUnchanged=' + ($afterHash -eq $beforeHash))
        }
        else { Write-Output 'FileMissingAfterRelease=True' }
    }
    else { Write-Output 'LOCK_NOT_ACQUIRED' }
    if (Test-Path -LiteralPath $releaseFile -PathType Leaf) { Remove-Item -LiteralPath $releaseFile }
}
