[CmdletBinding()]
param([string]$Root = (Split-Path -Parent $PSScriptRoot))

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$resolvedRoot = (Resolve-Path -LiteralPath $Root).Path
$prefix = $resolvedRoot.TrimEnd([char[]]@('\', '/')) + [IO.Path]::DirectorySeparatorChar
$manifestPath = Join-Path $resolvedRoot 'SHA256SUMS.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$checked = 0
foreach ($entry in $manifest.files) {
    $relative = $entry.path.Replace([char]'/', [IO.Path]::DirectorySeparatorChar)
    $file = [IO.Path]::GetFullPath((Join-Path $resolvedRoot $relative))
    if (-not $file.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw ('Invalid manifest path: ' + $entry.path)
    }
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
        throw ('Missing file: ' + $entry.path)
    }
    $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
    if ($actual -ne $entry.sha256) { throw ('SHA256 mismatch: ' + $entry.path) }
    $checked++
}
$pluginPath = Join-Path $resolvedRoot 'plugin\dsh-closet\package.json'
$plugin = Get-Content -LiteralPath $pluginPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($plugin.name -ne 'dsh-closet' -or $plugin.version -ne $manifest.pluginVersion) {
    throw 'Plugin identity does not match the package manifest.'
}
Write-Output ('Verified ' + $checked + ' files. Plugin: ' + $plugin.name + '@' + $plugin.version)
